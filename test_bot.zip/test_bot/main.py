from config import *

print("""
Bot started 

By : @FPFFG 
""")
app.run()