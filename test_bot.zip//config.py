from pyrogram import Client,filters
import redis



api_id = 15296051
api_hash = "4c3e35efa89e4a71172e986f80f57c7b"
token = token = input("Enter Token : ")
sudo_id = 1593178008
plugins = dict(root="plugins")
                 
def Owner(msg):
  if (msg.from_user.id == sudo_id) or (msg.from_user.id == bot_id) :
    ok = True
  else :
    ok = False
  return ok
  
app = Client("bot_y", bot_token=token, api_id = api_id, api_hash = api_hash,plugins=plugins)