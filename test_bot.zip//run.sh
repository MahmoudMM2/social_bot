apt-get update 
apt-get upgrade -y
apt install python3
apt install python3-pip
pip3 install -U pip
pip3 install -U setuptools
pip3 install -r r.txt -U
screen python3 main.py