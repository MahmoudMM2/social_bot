import asyncio
import requests
import pyrogram
from pyrogram import Client, filters,enums
from config import *
from pyrogram.types import ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton ,Message ,InputMediaPhoto
import os
from pySmartDL import SmartDL
from yt_dlp import  YoutubeDL

def is_url(url):
  listt = ["http" ,"instagram" ,".com" ,".net"]
  for i in listt :
    if i in url:
        return True
  return False

async def dow(url,name) :
    r = requests.get(url, allow_redirects=True)
    open(name, 'wb').write(r.content)
    return name
async def download_file(url,local_filename):
    dest = f"./{local_filename}" 
    obj = SmartDL(url, dest)
    obj.start()
    return local_filename
    
@Client.on_message(filters.private & filters.text)
async def homee(c,msg) :
  if not Owner(msg) :
    await msg.forward(sudo_id)
  if msg.text == "/start" :
    return await msg.reply("\n• اهلا بك في التحميل من المواقع فقط ارسل الرابط ..")
  if is_url(msg.text) :
    nn = f"{msg.from_user.id}" 
    url = f"https://xnxx.fastbots.ml/apies/dow.php?url={msg.text}"
    gettt = await c.send_message(msg.chat.id,text=f"🔃 getting data ..")
    try :
      j = requests.get(url).json()
    except :
      return await c.send_message(msg.chat.id,text=f"Error !")
    await gettt.delete()
    try :
      link = j['url'][0]['url']
      doww = await c.send_message(msg.chat.id,text=f"🔃 Downloading ..")
      video = await download_file(link,f"{nn}.mp4")
      await doww.delete()
      thumb = await dow(j['thumb'],f"{nn}.jpg")
      title = j['meta']['title']
      txx = f"[{title}]({msg.text})"
      uppp = await c.send_message(msg.chat.id,text=f"🔃 Uploading ..")
      await c.send_video(msg.chat.id,video=video,thumb=thumb,caption=txx)
      await uppp.delete()
    except TypeError :
      link = j[0]['url'][0]['url']
      doww = await c.send_message(msg.chat.id,text=f"🔃 Downloading ..")
      video = await download_file(link,f"{nn}.mp4")
      await doww.delete()
      thumb = await dow(j[0]['thumb'],f"{nn}.jpg")
      title = j[0]['meta']['title']
      txx = f"[{title}]({msg.text})"
      uppp = await c.send_message(msg.chat.id,text=f"🔃 Uploading ..")
      await c.send_video(msg.chat.id,video=video,thumb=thumb,caption=txx)
      await uppp.delete()
    except Exception as e:
      await c.send_message(msg.chat.id,text=f"Error !\n• {e}")
    try : 
      os.remove(video)
      os.remove(thumb)
    except :
      pass
  